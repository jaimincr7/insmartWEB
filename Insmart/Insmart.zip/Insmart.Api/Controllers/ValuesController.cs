﻿using Microsoft.AspNetCore.Mvc;

namespace Insmart.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
    }
}
