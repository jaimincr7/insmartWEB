﻿namespace Insmart.Api
{
    public class Test
    {
    }
}
