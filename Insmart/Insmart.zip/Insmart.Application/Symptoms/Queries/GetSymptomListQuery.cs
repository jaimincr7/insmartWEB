﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.Symptoms.Queries
{
    public class GetSymptomListQuery : PaginationFilter, IRequest<SymptomListQueryResult>
    {
        public int LanguageId { get; set; }
        public GetSymptomListQuery() { }

        public GetSymptomListQuery(int pageIndex, int pageSize)
        {
            PageNumber = pageIndex;
            PageSize = pageSize;
        }

    }
}
