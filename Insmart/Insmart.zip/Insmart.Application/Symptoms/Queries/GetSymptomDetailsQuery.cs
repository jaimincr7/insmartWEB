﻿using MediatR;

namespace Insmart.Application.Symptoms.Queries
{
    public class GetSymptomDetailsQuery: IRequest<SymptomDetailsQueryResult>
    {
        public int Id { get; set; }
    }
}
