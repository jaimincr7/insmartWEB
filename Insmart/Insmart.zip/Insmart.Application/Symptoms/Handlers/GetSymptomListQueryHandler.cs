﻿using AutoMapper;
using MediatR;
using Insmart.Application.Interfaces;
using Insmart.Application.Symptoms.Queries;

namespace Insmart.Application.Symptoms.Handlers
{
    public class GetSymptomListQueryHandler : IRequestHandler<GetSymptomListQuery, SymptomListQueryResult>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public GetSymptomListQueryHandler(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
        public async Task<SymptomListQueryResult> Handle(GetSymptomListQuery request, CancellationToken cancellationToken)
        {
            return await _unitOfWork.Symptoms.GetAllSymptomsAsync(request);
        }
    }
}
