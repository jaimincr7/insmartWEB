﻿namespace Insmart.Application.Models
{
    public class GetQuery
    {
        public int Id { get; set; }
    }
}
