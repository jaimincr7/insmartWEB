﻿using MediatR;

namespace Insmart.Application.Doctors.Queries
{
    public class GetDoctorDetailsQuery: IRequest<DoctorCompleteDetailsQueryResult>
    {
        public int Id { get; set; }
    }
}
