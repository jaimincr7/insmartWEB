﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.Doctors.Queries
{
    public class GetDoctorNamesListQuery : PaginationFilter, IRequest<DoctorNamesListQueryResult>
    {
        public string? Name { get; set; }

        public GetDoctorNamesListQuery() { }

        public GetDoctorNamesListQuery(int pageIndex, int pageSize)
        {
            PageNumber = pageIndex;
            PageSize = pageSize;
        }
    }
}
