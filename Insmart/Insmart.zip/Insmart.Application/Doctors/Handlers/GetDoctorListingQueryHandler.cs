﻿using AutoMapper;
using MediatR;
using Insmart.Application.Interfaces;
using Insmart.Application.Doctors.Queries;

namespace Insmart.Application.Doctors.Handlers
{
    public class GetDoctorListingQueryHandler : IRequestHandler<FilterDoctorListQuery, DoctorListingQueryResult>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public GetDoctorListingQueryHandler(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
        public async Task<DoctorListingQueryResult> Handle(FilterDoctorListQuery request, CancellationToken cancellationToken)
        {
            return await _unitOfWork.Doctors.GetDoctorListAsync(request);
        }
    }
}
