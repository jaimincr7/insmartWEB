﻿namespace Insmart.Application.Appointments
{
    public class GetUserAppointmentsQueryResult
    {
    }
}
