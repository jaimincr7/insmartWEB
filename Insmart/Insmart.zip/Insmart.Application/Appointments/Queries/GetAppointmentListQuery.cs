﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.Appointments.Queries
{
    public class GetAppointmentListQuery : PaginationFilter, IRequest<AppointmentListQueryResult>
    {
        public GetAppointmentListQuery() { }

        public GetAppointmentListQuery(int userId, int pageIndex, int pageSize)
        {
            UserId = userId;            
            PageNumber = pageIndex;
            PageSize = pageSize;
        }

        public int UserId { get; set; }
    }
}
