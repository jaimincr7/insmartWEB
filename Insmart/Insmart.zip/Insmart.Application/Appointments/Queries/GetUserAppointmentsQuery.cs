﻿using MediatR;

namespace Insmart.Application.Appointments.Queries
{
    public class GetUserAppointmentsQuery: IRequest<IList<AppointmentDetailsQueryResult>>
    {
    }
}
