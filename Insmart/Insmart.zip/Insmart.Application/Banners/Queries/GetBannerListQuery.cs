﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.Banners.Queries
{
    public class GetBannerListQuery : PaginationFilter, IRequest<BannerListQueryResult>
    {
        public int LanguageId { get; set; }
        public GetBannerListQuery() { }

        public GetBannerListQuery(int pageIndex, int pageSize)
        {
            PageNumber = pageIndex;
            PageSize = pageSize;
        }

    }
}
