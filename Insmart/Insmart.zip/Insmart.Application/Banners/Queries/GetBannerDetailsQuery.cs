﻿using MediatR;

namespace Insmart.Application.Banners.Queries
{
    public class GetBannerDetailsQuery: IRequest<BannerDetailsQueryResult>
    {
        public int Id { get; set; }
    }
}
