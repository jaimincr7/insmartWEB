﻿using Insmart.Core;

namespace Insmart.Application
{
    public class ListQueryResult
    {
        public Pagination? Pagination { get; set; }
    }
}
