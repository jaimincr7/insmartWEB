﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.PromoCodes.Queries
{
    public class GetPromoCodeListQuery : PaginationFilter, IRequest<PromoCodeListQueryResult>
    {
        public GetPromoCodeListQuery() { }

        public GetPromoCodeListQuery(int pageIndex, int pageSize)
        {
            PageNumber = pageIndex;
            PageSize = pageSize;
        }

    }
}
