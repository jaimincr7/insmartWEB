﻿using Insmart.Application.Features.Auth.Results;
using MediatR;

namespace Insmart.Application.Features.Auth.Queries
{
    public class ForgotPasswordQuery: IRequest<ForgotPasswordQueryResult>
    {
        public string Username { get; set; } = null!;
    }
}
