﻿namespace Insmart.Application.Features.Auth.Results
{
    public class ChangePasswordQueryResult
    {
        public bool IsSuccess { get; set; }
    }
}
