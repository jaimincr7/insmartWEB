﻿namespace Insmart.Application.Features.Auth.Results
{
    public class ForgotPasswordQueryResult
    {
        public string OTP { get; set; }
    }
}
