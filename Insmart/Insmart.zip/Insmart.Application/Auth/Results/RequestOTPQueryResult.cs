﻿namespace Insmart.Application.Features.Auth.Results
{
    public class RequestOTPQueryResult
    {
        public string OTP { get; set; }
    }
}
