﻿using AutoMapper;
using Insmart.Application.Features.Auth.Queries;
using Insmart.Application.Features.Auth.Results;
using Insmart.Application.Interfaces;
using Insmart.Application.Interfaces.Services;
using Insmart.Application.Models;
using Insmart.Core;
using Insmart.Core.DTOs;
using MediatR;

namespace Insmart.Application.Features.Auth.Handlers
{
    public class LoginWithOTPQueryHandler : IRequestHandler<LoginWithOTPQuery, LoginWithOTPQueryResult>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ITokenService _tokenService;
        private readonly IPasswordHashService _passwordHashService;
        public LoginWithOTPQueryHandler(IUnitOfWork unitOfWork, IMapper mapper, ITokenService tokenService, IPasswordHashService passwordHashService)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _tokenService = tokenService;
            _passwordHashService = passwordHashService;
        }
        public async Task<LoginWithOTPQueryResult> Handle(LoginWithOTPQuery query, CancellationToken cancellationToken)
        {
            LoginWithOTPQueryResult? result = new LoginWithOTPQueryResult();
            var dataQuery = new DapperQueryAndParams<User>()
            {
                RawSql = $"MobileNumber=@MobileNumber and IsDeleted=0",
                Parameters = new User() { MobileNumber = query.MobileNumber }
            };
            var user = await _unitOfWork.Users.GetAsync(dataQuery);

            if (1 == 1)  //TODOD - Validate OTP
            {
                result = _mapper.Map<LoginWithOTPQueryResult>(user);
            }

            return result;
        }
    }
}
