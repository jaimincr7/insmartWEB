﻿using AutoMapper;
using MediatR;
using Insmart.Application.Interfaces;
using Insmart.Application.Blogs.Queries;

namespace Insmart.Application.Blogs.Handlers
{
    public class GetBlogDetailsQueryHandler : IRequestHandler<GetBlogDetailsQuery, BlogDetailsQueryResult>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public GetBlogDetailsQueryHandler(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
        public async Task<BlogDetailsQueryResult> Handle(GetBlogDetailsQuery request, CancellationToken cancellationToken)
        {
            var result = await _unitOfWork.Blogs.GetAsync(request.Id);
            return _mapper.Map<BlogDetailsQueryResult>(result);
        }
    }
}
