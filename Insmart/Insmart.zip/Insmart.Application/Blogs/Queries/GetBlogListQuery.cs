﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.Blogs.Queries
{
    public class GetBlogListQuery : PaginationFilter, IRequest<BlogListQueryResult>
    {
        public int BlogCategoryId { get; set; }
        public GetBlogListQuery() { }

        public GetBlogListQuery(int pageIndex, int pageSize)
        {
            PageNumber = pageIndex;
            PageSize = pageSize;
        }

    }
}
