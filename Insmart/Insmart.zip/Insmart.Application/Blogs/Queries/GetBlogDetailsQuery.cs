﻿using Insmart.Application.Models;
using MediatR;

namespace Insmart.Application.Blogs.Queries
{
    public class GetBlogDetailsQuery : GetQuery, IRequest<BlogDetailsQueryResult>
    {
    }
}
