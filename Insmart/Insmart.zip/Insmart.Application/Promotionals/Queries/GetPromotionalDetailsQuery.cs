﻿using MediatR;

namespace Insmart.Application.Promotionals.Queries
{
    public class GetPromotionalDetailsQuery: IRequest<PromotionalDetailsQueryResult>
    {
        public int Id { get; set; }
    }
}
