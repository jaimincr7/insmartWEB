﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.Promotionals.Queries
{
    public class GetPromotionalListQuery : IRequest<PromotionalListQueryResult>
    {
    }
}
