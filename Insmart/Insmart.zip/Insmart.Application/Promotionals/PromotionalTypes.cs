﻿namespace Insmart.Core.Enums
{
    public enum PromotionalType
    {
        Doctor = 0,
        Hospital = 1,
        Speciality = 2,
        Symptoms = 3
    }
}
