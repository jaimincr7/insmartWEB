﻿namespace Insmart.Application.Promotionals
{
    public class PromotionalListQueryResult 
    {
        public IEnumerable<PromotionalDetailsQueryResult> Promotionals { get; set; }
    }
}
