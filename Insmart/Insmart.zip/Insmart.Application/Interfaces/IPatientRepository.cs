﻿using Insmart.Core.DTOs;

namespace Insmart.Application.Interfaces
{
    public interface IPatientRepository : IBaseRepository<Patient>
    {
    }
}