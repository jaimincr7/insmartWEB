﻿using Insmart.Core.DTOs;

namespace Insmart.Application.Interfaces
{
    public interface IAppointmentReviewRepository : IBaseRepository<AppointmentReview>
    {
    }
}