﻿using Insmart.Core.DTOs;

namespace Insmart.Application.Interfaces
{
    public interface ITestimonialRepository : IBaseRepository<Testimonial>
    {
    }
}