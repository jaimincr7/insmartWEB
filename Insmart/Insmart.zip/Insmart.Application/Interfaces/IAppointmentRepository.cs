﻿using Insmart.Core.DTOs;

namespace Insmart.Application.Interfaces
{
    public interface IAppointmentRepository : IBaseRepository<Appointment>
    {
    }
}