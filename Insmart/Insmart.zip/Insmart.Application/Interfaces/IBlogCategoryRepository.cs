﻿using Insmart.Core.DTOs;

namespace Insmart.Application.Interfaces
{
    public interface IBlogCategoryRepository : IBaseRepository<BlogCategory>
    {
    }
}