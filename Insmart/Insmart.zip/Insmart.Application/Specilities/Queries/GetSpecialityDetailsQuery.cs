﻿using MediatR;

namespace Insmart.Application.Specialities.Queries
{
    public class GetSpecialityDetailsQuery: IRequest<SpecialityDetailsQueryResult>
    {
        public int Id { get; set; }
    }
}
