﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.BlogCategories.Queries
{
    public class GetBlogCategoryListQuery : PaginationFilter, IRequest<BlogCategoryListQueryResult>
    {
        public GetBlogCategoryListQuery() { }

        public GetBlogCategoryListQuery(int pageIndex, int pageSize)
        {
            PageNumber = pageIndex;
            PageSize = pageSize;
        }

    }
}
