﻿using MediatR;

namespace Insmart.Application.Hospitals.Queries
{
    public class GetHospitalDetailsQuery: IRequest<HospitalDetailsQueryResult>
    {
        public int Id { get; set; }
    }
}
