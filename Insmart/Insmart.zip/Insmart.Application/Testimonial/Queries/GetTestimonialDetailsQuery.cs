﻿using MediatR;

namespace Insmart.Application.Testimonials.Queries
{
    public class GetTestimonialDetailsQuery: IRequest<TestimonialDetailsQueryResult>
    {
        public int Id { get; set; }
    }
}
