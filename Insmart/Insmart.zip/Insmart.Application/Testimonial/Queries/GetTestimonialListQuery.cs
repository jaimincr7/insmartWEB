﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.Testimonials.Queries
{
    public class GetTestimonialListQuery : PaginationFilter, IRequest<TestimonialListQueryResult>
    {
        public GetTestimonialListQuery() { }

        public GetTestimonialListQuery(int pageIndex, int pageSize)
        {
            PageNumber = pageIndex;
            PageSize = pageSize;
        }
    }
}
