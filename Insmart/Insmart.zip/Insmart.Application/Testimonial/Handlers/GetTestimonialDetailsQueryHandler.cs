﻿using AutoMapper;
using MediatR;
using Insmart.Application.Interfaces;
using Insmart.Application.Testimonials.Queries;

namespace Insmart.Application.Testimonials.Handlers
{
    public class GetTestimonialDetailsQueryHandler : IRequestHandler<GetTestimonialDetailsQuery, TestimonialDetailsQueryResult>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public GetTestimonialDetailsQueryHandler(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
        public async Task<TestimonialDetailsQueryResult> Handle(GetTestimonialDetailsQuery request, CancellationToken cancellationToken)
        {
            //var result = await _unitOfWork.REPO_CLASS_PROP_NAME.Add(_mapper.Map<Insmart.Core.Entities.Task>(request));
            //return result;
            throw new NotImplementedException();
        }
    }
}
