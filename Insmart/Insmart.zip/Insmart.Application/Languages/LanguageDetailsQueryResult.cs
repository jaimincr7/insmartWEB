﻿namespace Insmart.Application.Languages
{
    public class LanguageDetailsQueryResult 
    {
        public int LanguageId { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
    }
}
