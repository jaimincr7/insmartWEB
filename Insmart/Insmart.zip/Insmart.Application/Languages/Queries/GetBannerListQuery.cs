﻿using Insmart.Core;
using MediatR;

namespace Insmart.Application.Languages.Queries
{
    public class GetLanguageListQuery : PaginationFilter, IRequest<LanguageListQueryResult>
    {
        public GetLanguageListQuery() { }

        public GetLanguageListQuery(int pageIndex, int pageSize)
        {
            PageNumber = pageIndex;
            PageSize = pageSize;
        }

    }
}
