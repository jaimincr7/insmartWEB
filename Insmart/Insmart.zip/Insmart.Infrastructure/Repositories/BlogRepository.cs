﻿using Dapper;
using Insmart.Application.Blogs.Queries;
using Insmart.Application.Blogs;
using Insmart.Application.Interfaces;
using Insmart.Core;
using Insmart.Core.DTOs;
using Insmart.InfraStructure.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Insmart.Infrastructure.Repositories
{
    public class BlogRepository : BaseRepository<Blog>, IBlogRepository
    {
        readonly IConfiguration _configuration;
        readonly ILogger<BlogRepository> _logger;

        public BlogRepository(IConfiguration configuration, ILogger<BlogRepository> logger): base(configuration)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<BlogListQueryResult> GetAllBlogsAsync(GetBlogListQuery query)
        {
            var result = new BlogListQueryResult();

            var whereClause = "IsActive=1 and IsDeleted=0";

            DynamicParameters parameters = new DynamicParameters();

            if (query.BlogCategoryId > 0)
            {
                whereClause += " AND BlogCategoryId=@BlogCategoryId";
                parameters.Add("BlogCategoryId", query.BlogCategoryId);
            }


            var dataQuery = $"SELECT * FROM insmart.blogs /**where**/";
            var builder = new SqlBuilder().Where(whereClause, parameters);

            using (var connection = GetConnection())
            {
                if (query.PageNumber > 0 && query.PageSize > 0)
                {
                    dataQuery += $"limit {query.PageSize} offset {(query.PageNumber - 1) * query.PageSize}";
                    result.Pagination = new Pagination { PageNumber = query.PageNumber, PageSize = query.PageSize };
                    var counter = builder.AddTemplate($"SELECT count(*) FROM insmart.blogs /**where**/");
                    result.Pagination.TotalRecords = await connection.ExecuteScalarAsync<int>(counter.RawSql, counter.Parameters);
                }

                var selector = builder.AddTemplate(dataQuery);
                result.Blogs = await connection.QueryAsync<BlogDetailsQueryResult>(selector.RawSql, selector.Parameters);
            }

            return result;
        }
    }
}
